package com.example.foodhallapp;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.icu.text.DecimalFormat;
import android.icu.text.NumberFormat;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static java.security.AccessController.getContext;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {
    String  data2[],data3[];
    ArrayList<String> data1;
    int amounts[];
    ArrayList<Integer> images;
    Context context;
    onClickInterface onClickInterface;
    private ArrayList<ExampleItem> mExampleList;

   public MyAdapter(ArrayList<ExampleItem> exampleList,Context ct,onClickInterface onClickInterface) {
       mExampleList = exampleList;
       context = ct;
       this.onClickInterface = onClickInterface;
   }



    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.my_row, parent, false);
        MyViewHolder evh = new MyViewHolder(view);
        return evh;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        NumberFormat dec= new DecimalFormat("#0.00");
        File imgFile = new File("/src/main/ic_add2-playstore.png");
        if(position>=mExampleList.size()) {
            Drawable drawable = context.getResources().getDrawable(R.drawable.ic_add3);
            holder.Card.setForeground(drawable);
            holder.Card.setAlpha(1);
            holder.Card.setClickable(true);
            holder.myText1.setVisibility(View.GONE);
            holder.myText2.setVisibility(View.GONE);
            holder.myText3.setVisibility(View.GONE);
            holder.myText4.setVisibility(View.GONE);
            holder.Card.bringToFront();
            holder.Card.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    MainActivity.mExampleList.add(new ExampleItem("Name","Description","0.00",R.drawable.hamburger,0));
                    notifyItemInserted(position);
                    notifyDataSetChanged();
                    if ( context instanceof CheckOut ) {
                    }

                }
            });
        }
        else{
        holder.Card.setForeground(null);
        holder.Card.setClickable(false);
        holder.myText1.setVisibility(View.VISIBLE);
        holder.myText2.setVisibility(View.VISIBLE);
        holder.myText3.setVisibility(View.VISIBLE);
        holder.myText4.setVisibility(View.VISIBLE);
        ExampleItem currentItem = mExampleList.get(position);
        Double money =Double.parseDouble(currentItem.gets3())*currentItem.getam();
        holder.myText1.setText(currentItem.gets1());
        holder.myText2.setText(currentItem.gets2());
        holder.myText3.setText(currentItem.gets3());
        if(currentItem.getam()==0){
            holder.myText4.setVisibility(View.INVISIBLE);
        }
        else{
            holder.myText4.setVisibility(View.VISIBLE);
        }
        if(currentItem.getam()>0){
        holder.myText4.setText(Integer.toString(currentItem.getam()));}
        holder.myImage.setImageResource(currentItem.getimg());
        if ( context instanceof CheckOut ) {
            holder.cart.setImageResource(R.drawable.ic_remove);
            holder.myText3.setText(currentItem.gets3()+"x"+currentItem.getam()+" = $"+dec.format(money));
        }
        holder.cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if ( context instanceof CheckOut ) {

                }
                String T1 = holder.myText1.getText().toString();
                String T2 = holder.myText2.getText().toString();;
                String T3 = dec.format(Double.parseDouble(currentItem.gets3()));
                int T4 = currentItem.getimg();
                onClickInterface.setClick(position,T1,T2,T3,T4);
            }
        });}}




    @Override
    public int getItemCount() {
        if (mExampleList.size()>0){
        return mExampleList.size()+1;}
        else{return 0;}
    }

    class MyViewHolder extends  RecyclerView.ViewHolder{
       EditText myText1,myText2,myText3;
       TextView myText4,Price;
       ImageView myImage,cart;
       ConstraintLayout Constraint;
       CardView Card;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            myText1 = itemView.findViewById(R.id.myText1);
            myText2 = itemView.findViewById(R.id.myText2);
            myText3 = itemView.findViewById(R.id.myText3);
            myText4 = itemView.findViewById(R.id.myText4);
            myImage = itemView.findViewById(R.id.myImageView);
            cart = itemView.findViewById(R.id.cart);
            Price = itemView.findViewById(R.id.Price);
            Constraint = itemView.findViewById(R.id.Con2);
            Card = itemView.findViewById(R.id.Card);
        }
    }
    public void removeAt(int position) {
        mExampleList.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, mExampleList.size());
    }
}
