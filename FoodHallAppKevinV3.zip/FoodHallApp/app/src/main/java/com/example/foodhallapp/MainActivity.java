package com.example.foodhallapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.util.Collection;
import java.util.List;
import android.database.sqlite.SQLiteDatabase;

import static java.lang.String.valueOf;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    String s2[],s3[];
    ArrayList<String> s1;
    ArrayList<Integer> images= new ArrayList<>(Arrays.asList(R.drawable.fries,R.drawable.hamburger,R.drawable.hotdog,R.drawable.pizza));
    int am[]= new int[images.size()];
    public static MyAdapter myAdapter;
    public static CustomAdapter CustomAdapter;
    private SQLiteDatabase mDatabase;
    Context context;
    Cursor mCursor;
    orderDatabaseHelper myDB;
    ArrayList<String> book_id, book_title, book_author, book_pages;
    public static ArrayList<ExampleItem> mExampleList;
    onClickInterface onclickInterface;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        myDB = new orderDatabaseHelper(MainActivity.this);
        s1 = new ArrayList<String>(Arrays.asList(getResources().getStringArray(R.array.Dish_Name)));
        s2 = getResources().getStringArray(R.array.Dish_Description);
        s3 = getResources().getStringArray(R.array.Price);
        mExampleList = new ArrayList<>();
        ArrayList<String> book_id, book_title, book_author, book_pages;
        mExampleList.add(new ExampleItem(s1.get(0),s2[0],s3[0],R.drawable.hamburger,0));
        mExampleList.add(new ExampleItem(s1.get(1),s2[1],s3[1],R.drawable.hotdog,0));
        mExampleList.add(new ExampleItem(s1.get(2),s2[2],s3[2],R.drawable.pizza,0));
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recyclerView);
        onclickInterface = new onClickInterface() {
            @Override
            public void setClick(int abc,String T1,String T2,String T3,int T4) {
                //myDB.insertData(T1);//
                //abc = CustomAdapter.getId();//
                Log.d( String.valueOf(abc),String.valueOf(T4));
                CustomAdapter.swapCursor(getAllItems());
                myDB.modifyData(abc,T1,T2,T3,T4);
                CustomAdapter.notifyDataSetChanged();
            }
        };
        ImageView Header = findViewById(R.id.imageView);
        TextView Name = findViewById(R.id.Name);
        TextView Description = findViewById(R.id.textView2);
        myAdapter = new MyAdapter(mExampleList,this,onclickInterface);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
       // myDB.DeleteAll();//
        //myDB.insertData(s1.get(0),s2[0],s3[0],R.drawable.hamburger,6);//
        mDatabase = myDB.getWritableDatabase();
        CustomAdapter= new CustomAdapter(this, getAllItems(),onclickInterface);
        recyclerView.setAdapter(CustomAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

    }
    public void Checkout(View view) {
        Intent intent = new Intent(view.getContext(), CheckOut.class);
        Bundle b=new Bundle();
        b.putStringArrayList("s1", s1);
        b.putStringArray("s2", s2);
        b.putStringArray("s3",s3);
        b.putIntegerArrayList("images",images);
        b.putIntArray("am",am);

        intent.putExtras(b);

        startActivity(intent);
    }


    private Cursor getAllItems() {
        return mDatabase.query(
                itemHelper.OrderEntry.Table_Name,
                null,
                null,
                null,
                null,
                null,
                itemHelper.OrderEntry.COLUMN_PRICE+ " DESC"
        );
    }

    private void Change(long id) {
        String selection = "_id ="+id;
        ContentValues args = new ContentValues();
        mDatabase.update(itemHelper.OrderEntry.Table_Name,args,
                selection, null);
        CustomAdapter.swapCursor(getAllItems());
    }

}
