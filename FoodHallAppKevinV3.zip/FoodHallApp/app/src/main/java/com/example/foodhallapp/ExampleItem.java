package com.example.foodhallapp;

import android.content.Context;

import java.util.ArrayList;
import java.util.Arrays;

public class ExampleItem {
    String ms1,ms2,ms3;
    int mimages,mam;
    public ExampleItem(String s1, String s2, String s3, int img, int am) {
        ms1 = s1;
        ms2 = s2;
        ms3 = s3;
        mimages = img;
        mam = am;
    }
    public String gets1() {
        return ms1;
    }
    public String gets2() {
        return ms2;
    }
    public String gets3() {
        return ms3;
    }
    public int getimg() {
        return mimages;
    }
    public int getam() {
        return mam;
    }

}
