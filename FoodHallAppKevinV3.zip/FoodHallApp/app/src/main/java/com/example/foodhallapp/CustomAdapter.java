package com.example.foodhallapp;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.icu.text.DecimalFormat;
import android.icu.text.NumberFormat;
import android.os.Build;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder> {
    String  data2[],data3[];
    ArrayList<String> data1;
    int amounts[];
    ArrayList<Integer> images;
    Context context;
    Cursor mCursor;
    onClickInterface onClickInterface;
    private ArrayList<ExampleItem> mExampleList;

    public CustomAdapter(Context ct, Cursor cursor, onClickInterface onClickInterface) {
        mCursor = cursor;
        context = ct;
        this.onClickInterface = onClickInterface;
    }



    @NonNull
    @Override
    public CustomAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.my_row, parent, false);
        CustomAdapter.MyViewHolder evh = new CustomAdapter.MyViewHolder(view);
        return evh;
    }

    @Override
    public void onBindViewHolder(@NonNull CustomAdapter.MyViewHolder holder, int position) {
        NumberFormat dec= new DecimalFormat("#0.00");
        File imgFile = new File("/src/main/ic_add2-playstore.png");
        if (!mCursor.moveToPosition(position)) {
            return;
        }
            holder.Card.setForeground(null);
            holder.Card.setClickable(false);
            long id = mCursor.getLong(mCursor.getColumnIndex(itemHelper.OrderEntry._ID));
            holder.itemView.setTag(id);
            holder.myText1.setVisibility(View.VISIBLE);
            holder.myText2.setVisibility(View.VISIBLE);
            holder.myText3.setVisibility(View.VISIBLE);
            holder.myText4.setVisibility(View.VISIBLE);
            holder.myText1.setText( mCursor.getString(mCursor.getColumnIndex(itemHelper.OrderEntry.COLUMN_NAME)));
            holder.myText2.setText(mCursor.getString(mCursor.getColumnIndex(itemHelper.OrderEntry.COLUMN_DESC)));
            holder.myText3.setText(mCursor.getString(mCursor.getColumnIndex(itemHelper.OrderEntry.COLUMN_PRICE)));
            holder.myImage.setImageResource(mCursor.getInt(mCursor.getColumnIndex(itemHelper.OrderEntry.COLUMN_IMG)));
            holder.myText4.setText(mCursor.getString(mCursor.getColumnIndex(itemHelper.OrderEntry.COLUMN_AM)));
            if(mCursor.getInt(mCursor.getColumnIndex(itemHelper.OrderEntry.COLUMN_AM))==0){
                holder.myText4.setVisibility(View.INVISIBLE);
            }
            else{
                holder.myText4.setVisibility(View.VISIBLE);
            }
        if ( context instanceof CheckOut ) {
            holder.cart.setImageResource(R.drawable.ic_remove);
            int money = mCursor.getInt(mCursor.getColumnIndex(itemHelper.OrderEntry.COLUMN_PRICE))*mCursor.getInt(mCursor.getColumnIndex(itemHelper.OrderEntry.COLUMN_AM));
            holder.myText3.setText(mCursor.getString(mCursor.getColumnIndex(itemHelper.OrderEntry.COLUMN_PRICE))+"x"+mCursor.getString(mCursor.getColumnIndex(itemHelper.OrderEntry.COLUMN_AM))+" = $"+dec.format(money));
            if(mCursor.getInt(mCursor.getColumnIndex(itemHelper.OrderEntry.COLUMN_AM))==0){
                holder.Card.setVisibility(View.GONE);
            }
            else{
                holder.Card.setVisibility(View.VISIBLE);
            }
        }
            holder.cart.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if ( context instanceof CheckOut ) {
                    }
                    String T1 = holder.myText1.getText().toString();
                    String T2 = holder.myText2.getText().toString();;
                    String T3;
                    //int T4 = holder.getAdapterPosition();//
                    if( context instanceof CheckOut ){
                    T3 = mCursor.getString(mCursor.getColumnIndex(itemHelper.OrderEntry.COLUMN_PRICE));}
                    else{
                        T3 = holder.myText3.getText().toString();
                    }
                    mCursor.moveToPosition(holder.getAdapterPosition());
                    Log.d("Small",String.valueOf(position));
                    //int T4 = (int) holder.itemView.getTag();//
                    int T4 = mCursor.getInt(mCursor.getColumnIndex(itemHelper.OrderEntry._ID));
                    mCursor.moveToPosition(holder.getAdapterPosition());
                    int abc = Integer.parseInt(mCursor.getString(mCursor.getColumnIndex(itemHelper.OrderEntry.COLUMN_AM)))+1;
                    Log.d("BIG",String.valueOf(T4));
                    onClickInterface.setClick(abc,T1,T2,T3,T4);
                    notifyDataSetChanged();
                }
            });}




    @Override
    public int getItemCount() {
        return mCursor.getCount();
    }

    public void swapCursor(Cursor newCursor) {
        if (mCursor != null) {
            mCursor.close();
        }
        mCursor = newCursor;
        if (newCursor != null) {
            notifyDataSetChanged();
        }
    }

    class MyViewHolder extends  RecyclerView.ViewHolder{
        EditText myText1,myText2,myText3;
        TextView myText4,Price;
        ImageView myImage,cart;
        ConstraintLayout Constraint;
        CardView Card;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            myText1 = itemView.findViewById(R.id.myText1);
            myText2 = itemView.findViewById(R.id.myText2);
            myText3 = itemView.findViewById(R.id.myText3);
            myText4 = itemView.findViewById(R.id.myText4);
            myImage = itemView.findViewById(R.id.myImageView);
            cart = itemView.findViewById(R.id.cart);
            Price = itemView.findViewById(R.id.Price);
            Constraint = itemView.findViewById(R.id.Con2);
            Card = itemView.findViewById(R.id.Card);
        }
    }
    public void removeAt(int position) {
        mExampleList.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, mExampleList.size());
    }
    int getId(){
        return mCursor.getInt(mCursor.getColumnIndex(itemHelper.OrderEntry._ID));
    }
}
