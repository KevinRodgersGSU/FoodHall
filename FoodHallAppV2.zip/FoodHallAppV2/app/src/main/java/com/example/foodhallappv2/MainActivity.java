package com.example.foodhallappv2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;




public class MainActivity extends AppCompatActivity {
    String[] s1;
    String[] s2;
    Integer[] d3;
    RecyclerView rMenuView;
    RecyclerView.LayoutManager layoutManager1;
    vendorMenuAdapter mAdapter;
    orderSummaryAdapter sumAdapter;
    orderDatabaseHelper myDb;
    TextView orderNum;
    TextView orderPrice;
    int currOrder;
    private AppBarConfiguration mAppBarConfiguration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       /* Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        */


        rMenuView = (RecyclerView) findViewById(R.id.menuView);
        layoutManager1 = new LinearLayoutManager(getApplicationContext());
        rMenuView.setLayoutManager(layoutManager1);
        rMenuView.setItemAnimator(new DefaultItemAnimator());
        myDb = new orderDatabaseHelper(this);

        getMenuInfo();


        mAdapter = new vendorMenuAdapter(s1, s2, d3);
        rMenuView.setAdapter(mAdapter);

        currOrder = myDb.getLastOrder()+1;
        orderNum = findViewById(R.id.MainOrdNum);
        orderNum.setText(String.valueOf(currOrder));


    }
    private void getMenuInfo() {
        s1 = menuProvider.generateMenuNum();
        s2 = menuProvider.generateMenuDesc();
        d3 = menuProvider.generateMenuPrice();
    }

    public void ReviewOrder(View v){

        Intent intent = new Intent(this, ReviewOrder.class);
        startActivity(intent);


    }

}