package com.example.foodhallappv2;

import java.util.Random;

public class menuProvider {
    private static int count = 10;

    public static String[] generateMenuDesc(){
        String[] menuSet = new String[count];
        for (int i=0; i<count; i++){
            menuSet[i] = "This is Menu Item " + (i+1) + " description";
        }
        return menuSet;
    }
    public static String[] generateMenuNum(){
        String[] menuNum= new String[count];
        for (int i=0; i<count; i++){
            menuNum[i] = ""+(i+1);
        }
        return menuNum;
    }

    public static Integer[] generateMenuPrice(){
        Integer[] menuPrice = new Integer[count];
        for (int i=0; i<count; i++){
            menuPrice[i] = 10;
        }
        return menuPrice;
    }
}
