package com.example.foodhallappv2;

import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class orderSummaryAdapter extends RecyclerView.Adapter<orderSummaryAdapter.myViewHolder> {
    orderDatabaseHelper myDb;
    private String[] dataSet1, dataSet2;
    private Integer[] dataSet3;
    List SumOrderDesc, SumOrderInst, SumOrderID, SumOrderPrice;

    public orderSummaryAdapter(List OrderID, List OrderDesc, List OrderPrice, List OrderInst){
        SumOrderInst = OrderInst;
        SumOrderID = OrderID;
        SumOrderDesc = OrderDesc;
        SumOrderPrice = OrderPrice;

    }


    @NonNull
    @Override
    public orderSummaryAdapter.myViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.summary_item, parent, false);
        myViewHolder vh = new myViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull orderSummaryAdapter.myViewHolder holder, int position) {
        holder.TVOrderID.setText((String)SumOrderID.get(position));
        holder.TVOrderInst.setText((String) SumOrderInst.get(position));
        holder.TVOrderDesc.setText((String)SumOrderDesc.get(position));
        holder.TVOrderPrice.setText((String)SumOrderPrice.get(position));
        holder.removeOrd.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){
                myDb = new orderDatabaseHelper(v.getContext());
                //Code to add orders from menu into database
                int delOrderID = Integer.valueOf(holder.TVOrderID.getText().toString());
                myDb.deleteOrder(delOrderID);
                removeItem(position);
            }
        });


    }
    public void removeItem(int position){
        SumOrderDesc.remove(position);
        SumOrderInst.remove(position);
        SumOrderID.remove(position);
        notifyDataSetChanged();

    }

    @Override
    public int getItemCount() {
        return SumOrderID.size();
    }

    public class myViewHolder extends RecyclerView.ViewHolder {
        private TextView TVOrderID, TVOrderDesc, TVOrderInst, TVOrderPrice;
        Button removeOrd;

        public myViewHolder(View v) {
            super(v);
            TVOrderID = v.findViewById(R.id.sumTXTOrderID);
            TVOrderDesc = v.findViewById(R.id.sumTXTdesc);
            TVOrderInst = v.findViewById(R.id.sumInst);
            TVOrderPrice = v.findViewById(R.id.sumPriceItem);
            removeOrd = v.findViewById(R.id.removeItem);
            myDb = new orderDatabaseHelper(v.getContext());

        }
    }
}
