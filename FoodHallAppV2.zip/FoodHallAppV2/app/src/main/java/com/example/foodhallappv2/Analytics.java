package com.example.foodhallappv2;

import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;

import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;


public class Analytics extends AppCompatActivity{
    BarChart barchart;
    orderDatabaseHelper myDb;
    TextView stat1, stat2, stat3, sLabel1, sLabel2, sLabel3;
    int[] menuOrderCount;
    int revenue, count;
    String[] s1;
    String[] s2;
    Integer[] d3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        stat1 = findViewById(R.id.stats1);
        stat2 = findViewById(R.id.stats2);
        stat3 = findViewById(R.id.stats3);
        sLabel1 = findViewById(R.id.statsLabel1);
        sLabel2 = findViewById(R.id.statsLabel2);
        sLabel3 = findViewById(R.id.statsLabel3);
        myDb = new orderDatabaseHelper(this);


        Cursor res = myDb.getAllData();
        menuOrderCount = new int[10];
        revenue = 0;
        count = 0;
        while (res.moveToNext()){
            int val = res.getInt(1)-1;
            menuOrderCount[val]++;
            revenue = revenue+res.getInt(4);
            count++;
        }

        //Graphing Stuff
        setContentView(R.layout.vendor_analytics);
        BarChart barchart = findViewById(R.id.barChart);
        ArrayList<BarEntry> value = new ArrayList<>();
        for (int i=0;i<10;i++){
            value.add(new BarEntry(i+1,menuOrderCount[i]));

        }

        BarDataSet barDataSet = new BarDataSet(value,"Item Sales");
        barDataSet.setColors(ColorTemplate.MATERIAL_COLORS);
        barDataSet.setValueTextColor(Color.BLACK);
        barDataSet.setValueTextSize(16f);

        BarData barData = new BarData(barDataSet);

        barchart.setFitBars(true);
        barchart.setData(barData);
        barchart.getDescription().setText("Sales by Menu Item");
        barchart.getDescription().setTextSize(16f);

    }
    public void ShowChart(View v){

        int bestSeller = getMax(menuOrderCount);
        ShowSales(bestSeller);

    }

    public int getMax(int[] arr){
        int menuIndex=0;
        for (int i=0;i<arr.length;i++){
            if (arr[i] > arr[menuIndex]){
                menuIndex=i;
            }
        }
        return menuIndex+1;
    }

    public void ShowSales(int topSell){
        stat1 = findViewById(R.id.stats1);
        stat2 = findViewById(R.id.stats2);
        stat3 = findViewById(R.id.stats3);
        sLabel1 = findViewById(R.id.statsLabel1);
        sLabel2 = findViewById(R.id.statsLabel2);
        sLabel3 = findViewById(R.id.statsLabel3);
        sLabel1.setText("Total Revenue: ");
        stat1.setText("$"+String.valueOf(revenue));
        sLabel2.setText("Total Items Sold: ");
        stat2.setText(String.valueOf(count));
        sLabel3.setText("Top Selling Menu Item: ");
        stat3.setText(String.valueOf(topSell));

        BarChart barchart = findViewById(R.id.barChart);
        barchart.invalidate();


    }

    public void showMessage(String title, String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }


    public void ShowItems(View view) {
        StringBuffer buffer = new StringBuffer();
        s1 = menuProvider.generateMenuNum();
        s2 = menuProvider.generateMenuDesc();
        d3 = menuProvider.generateMenuPrice();

        for (int i=0;i<s1.length;i++) {
            buffer.append("Menu Number: " + (i + 1) + "\n");
            buffer.append("Order Description :" + s2[i] + "\n");
            buffer.append("Order Price :" + d3[i] + "\n\n");
        }
        showMessage("Current Menu", buffer.toString());
    }
}