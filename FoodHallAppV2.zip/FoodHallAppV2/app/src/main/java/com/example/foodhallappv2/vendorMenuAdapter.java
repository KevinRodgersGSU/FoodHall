package com.example.foodhallappv2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class vendorMenuAdapter extends RecyclerView.Adapter<vendorMenuAdapter.myViewHolder> {
    private String[] dataSet1, dataSet2;
    private Integer[] dataSet3;
    public static int orderNumber;
    orderDatabaseHelper myDb;
    orderSummaryAdapter SumAdapter;



    public vendorMenuAdapter(String[] data1, String[] data2, Integer[] data3) {
        dataSet1 = data1;
        dataSet2 = data2;
        dataSet3 = data3;

    }

    @NonNull
    @Override
    public vendorMenuAdapter.myViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.vendor_item, parent, false);
        myViewHolder vh = new myViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull vendorMenuAdapter.myViewHolder holder, int position) {
        holder.menuNum.setText(dataSet1[position]);
        holder.menuDescript.setText(dataSet2[position]);
        holder.menuPrice.setText(dataSet3[position].toString());
        holder.addBtn.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){
                myDb = new orderDatabaseHelper(v.getContext());
                //Code to add orders from menu into database
                int menuItemNum = Integer.valueOf(holder.menuNum.getText().toString());
                String menuItemDesc = holder.menuDescript.getText().toString();
                int menuItemPrice = Integer.valueOf(holder.menuPrice.getText().toString());
                String menuItemInstr = holder.menuInstr.getText().toString();
                myDb.insertData(menuItemNum,myDb.orderNumber+1,menuItemDesc,menuItemPrice,menuItemInstr);
            }
        });

    }

    @Override
    public int getItemCount() {
        return dataSet1.length;
    }

    public class myViewHolder extends RecyclerView.ViewHolder {
        private TextView menuNum, menuDescript, menuPrice;
        private EditText menuInstr;
        //private TextView orderPrice;
        Button addBtn;



        public myViewHolder(View v){
            super(v);
            menuNum = v.findViewById(R.id.menuTXTnum);
            menuDescript = v.findViewById(R.id.menuTXTdesc);
            menuPrice = v.findViewById(R.id.priceText);
            addBtn = v.findViewById(R.id.addItem);
            menuInstr = v.findViewById(R.id.ordInst);
            myDb = new orderDatabaseHelper(v.getContext());
            orderNumber=myDb.getLastOrder()+1;


        }
    }
}
