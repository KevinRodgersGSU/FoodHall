package com.example.foodhallappv2;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ReviewOrder extends AppCompatActivity {
    TextView orderNum;
    TextView orderPrice;
    orderDatabaseHelper myDb;
    RecyclerView rSumView;
    RecyclerView.LayoutManager layoutManager2;
    orderSummaryAdapter sumAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.order_summary);

        orderNum = findViewById(R.id.ordTXTNum);
        myDb = new orderDatabaseHelper(this);

        Cursor res = myDb.getAllData();
        StringBuffer buffer = new StringBuffer();
        int currOrder = myDb.orderNumber;
        //int currOrder =  Integer.valueOf(orderNum.getText().toString());
        List OrderDesc, OrderInst, OrderID, OrderNum, OrderPrice;
        OrderDesc = new ArrayList();
        OrderInst = new ArrayList();
        OrderID = new ArrayList();
        OrderNum = new ArrayList();
        OrderPrice = new ArrayList();
        int priceTotal = 0;
        int ind=0;
        while (res.moveToNext()) {
            if (res.getInt(2)==currOrder+1) {
                OrderDesc.add(ind,res.getString(3));
                OrderInst.add(ind,res.getString(5));
                OrderID.add(ind,res.getString(0));
                OrderNum.add(ind,currOrder);
                OrderPrice.add(ind,res.getString(4));
                ind++;

            }
        }

        orderNum.setText(String.valueOf(myDb.orderNumber+1));

        rSumView = (RecyclerView) findViewById(R.id.summaryRview);
        layoutManager2 = new LinearLayoutManager(getApplicationContext());
        rSumView.setLayoutManager(layoutManager2);
        rSumView.setItemAnimator(new DefaultItemAnimator());

        sumAdapter = new orderSummaryAdapter(OrderID, OrderDesc, OrderPrice, OrderInst);
        rSumView.setAdapter(sumAdapter);



    }

    public void AddOrder(View view) {

        Cursor res = myDb.getAllData();
        StringBuffer buffer = new StringBuffer();
        int currOrder = myDb.orderNumber;
        //int currOrder =  Integer.valueOf(orderNum.getText().toString());
        List OrderDesc, OrderInst, OrderID, OrderNum, OrderPrice;
        OrderDesc = new ArrayList();
        OrderInst = new ArrayList();
        OrderID = new ArrayList();
        OrderNum = new ArrayList();
        OrderPrice = new ArrayList();
        int priceTotal = 0;
        int ind=0;
        while (res.moveToNext()) {
            if (res.getInt(2)==currOrder+1) {
                OrderDesc.add(ind,res.getString(3));
                OrderInst.add(ind,res.getString(5));
                OrderID.add(ind,res.getString(0));
                OrderNum.add(ind,currOrder);
                OrderPrice.add(ind,res.getString(4));
                priceTotal = priceTotal + res.getInt(4);
                ind++;

            }
        }
        for (int i=0;i<ind;i++){
            buffer.append("ID :" + OrderID.get(i) + "\n");
            buffer.append("Order Description :" + OrderDesc.get(i) + "\n");
            buffer.append("Order Price :" + OrderPrice.get(i) + "\n");
            buffer.append("Order Instruction :" + OrderInst.get(i) + "\n\n");
        }
        buffer.append("Total Price: $"+priceTotal);
        showMessage("Order Number "+(currOrder+1)+" Confirmed", buffer.toString());
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                updateData();
            }
        }, 5000);
    }


    public void updateData(){
        myDb.orderNumber++;
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("ordNum",myDb.orderNumber+1);
        startActivity(intent);

    }

    public void showMessage(String title, String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}
