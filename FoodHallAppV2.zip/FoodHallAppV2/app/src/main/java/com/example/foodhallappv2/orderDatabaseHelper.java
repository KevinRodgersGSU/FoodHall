package com.example.foodhallappv2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.foodhallappv2.itemHelper.*;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class orderDatabaseHelper extends SQLiteOpenHelper {

    private final static String DATABASE_NAME = "ordersList.db";
    private final static int DATABASE_VERSION = 1;
    public static int orderNumber;

    public orderDatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        //SQLiteDatabase db = this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        final String SQL_CREATE_ORDER_TABLE = "CREATE TABLE " +
                OrderEntry.Table_Name + " (" +
                OrderEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                OrderEntry.COLUMN_ITEM_NUM + " INTEGER, " +
                OrderEntry.COLUMN_ORDER_NUM + " INTEGER, " +
                OrderEntry.COLUMN_DESC + " TEXT, " +
                OrderEntry.COLUMN_PRICE + " INTEGER, " +
                OrderEntry.COLUMN_INSTR + " TEXT, " +
                OrderEntry.COLUMN_DATETIME + " TIMESTAMP DEFAULT CURRENT_TIMESTAMP " +
                ");";
        db.execSQL(SQL_CREATE_ORDER_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + OrderEntry.Table_Name);
        onCreate(db);
    }
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + OrderEntry.Table_Name);
        onCreate(db);
    }

    public boolean insertData(int itemNum, int orderNum, String desc, int price, String instr){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(OrderEntry.COLUMN_ITEM_NUM, itemNum);
        contentValues.put(OrderEntry.COLUMN_ORDER_NUM, orderNum);
        contentValues.put(OrderEntry.COLUMN_DESC, desc);
        contentValues.put(OrderEntry.COLUMN_PRICE, price);
        contentValues.put(OrderEntry.COLUMN_INSTR, instr);
        long result = db.insert(OrderEntry.Table_Name, null, contentValues);
        if(result ==-1)
            return false;
        else
            return true;
    }

    public Cursor getAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("SELECT * FROM "+OrderEntry.Table_Name,null);
        return res;
    }

    public int getLastOrder(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("SELECT * FROM "+OrderEntry.Table_Name,null);
        res.moveToLast();
        int lastOrderNum = res.getInt(2);
        orderNumber=lastOrderNum;
        return lastOrderNum;

    }

    public void getCurrentOrder(){

        /*
        SQLiteDatabase db = this.getWritableDatabase();
        int currOrder = getLastOrder()+1;
        Cursor res = getAllData();
        List OrderDesc, OrderInst, OrderID, OrderNum, OrderPrice;
        OrderDesc = new ArrayList();
        OrderInst = new ArrayList();
        OrderID = new ArrayList();
        OrderNum = new ArrayList();
        OrderPrice = new ArrayList();
        int ind=0;
        while (res.moveToNext()){
            if (res.getInt(3)==currOrder){
                OrderDesc.add(ind,res.getString(4));
                OrderPrice.add(ind,res.getInt(5));
                OrderInst.add(ind,res.getString(6));
                OrderID.add(ind,res.getInt(1));
            }

        }


        */
        //return orderInfo;
    }

    public void deleteOrder(int id){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(OrderEntry.Table_Name,OrderEntry._ID+"="+id,null);
    }

    public int getOrderPrice(){
        SQLiteDatabase db = this.getWritableDatabase();
        int currOrder = getLastOrder()+1;
        Cursor res = getAllData();
        int currOrderPrice=0;
        while (res.moveToNext()){
            if (res.getInt(3)==currOrder){
                currOrderPrice = currOrderPrice+res.getInt(5);
            }
        }
        return currOrderPrice;
    }


}

