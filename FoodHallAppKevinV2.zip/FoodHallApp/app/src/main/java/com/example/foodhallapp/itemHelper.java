package com.example.foodhallapp;

import android.provider.BaseColumns;

import static android.os.Build.ID;

public class itemHelper {


    public static final class OrderEntry implements BaseColumns {
        public static final String Table_Name = "orderList";
        public static final String COLUMN_NAME= "MenuNum";
        public static final String COLUMN_DESC = "OrderNum";
        public static final String COLUMN_PRICE = "Price";
        public static final String COLUMN_IMG = "Description";
        public static final String COLUMN_AM = "Instructions";
    }

    public static String getID() {
        return ID;
    }
}
