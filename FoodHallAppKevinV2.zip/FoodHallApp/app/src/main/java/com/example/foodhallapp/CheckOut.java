package com.example.foodhallapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.icu.text.DecimalFormat;
import android.icu.text.NumberFormat;
import android.os.Bundle;
import android.os.Parcelable;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class CheckOut extends AppCompatActivity {
    String  c2[],c3[];
    ArrayList<String> c1;
    int cam[];
    ArrayList<Integer> cimages;
    onClickInterface onclickInterface2;
    RecyclerView RecyclerView;
    private MyAdapter myAdapter2;
    private ArrayList<ExampleItem> mExampleList2,mExampleList3;
    private static Context context;
    private Double price = 0.00;
    orderDatabaseHelper myDB;
    private SQLiteDatabase mDatabase;
    public static CustomAdapter CustomAdapter2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CheckOut.context = getApplicationContext();
        NumberFormat dec= new DecimalFormat("#0.00");
        setContentView(R.layout.activity_check_out);
        RecyclerView = findViewById(R.id.RecyclerView);
        Button button2= findViewById(R.id.price);
        Intent intent = getIntent();
        Bundle b=intent.getExtras();
        c1=b.getStringArrayList("s1");
        String[] c2=b.getStringArray("s2");
        String[] c3=b.getStringArray("s3");
        int[] cam = b.getIntArray("am");
        cimages = b.getIntegerArrayList("images");
        mExampleList2 = new ArrayList<ExampleItem>(MainActivity.mExampleList);
        mExampleList3 = new ArrayList<ExampleItem>();
        for(ExampleItem item : mExampleList2){
            if(item.getam()==0){
                mExampleList3.add(item);
            }
            else{
                price = price + Double.parseDouble(item.gets3())*item.getam();
            }
        }
        button2.setText(dec.format(price));
        mExampleList2.removeAll(mExampleList3);
        int priceTotal = 0;
        onclickInterface2 = new onClickInterface() {
            int z=0;
            @Override
            public void setClick(int abc,String T1,String T2,String T3,int T4) {
                CustomAdapter2.swapCursor(getAllItems());
                myDB.modifyData(0,T1,T2,T3,T4);
                CustomAdapter2.notifyDataSetChanged();
                myDB.modifyData(0,T1,T2,T3,T4);
                MainActivity.CustomAdapter.notifyDataSetChanged();
                }
        };
        /*if(mExampleList2!=null){
        myAdapter2 = new CustomAdapter(mExampleList2,this,onclickInterface2);
        RecyclerView.setAdapter(myAdapter2);}
        RecyclerView.setLayoutManager(new LinearLayoutManager(this));*/
        RecyclerView recyclerView = findViewById(R.id.RecyclerView);
        myDB = new orderDatabaseHelper(CheckOut.this);
        mDatabase = myDB.getWritableDatabase();
        CustomAdapter2 = new CustomAdapter(this, getAllItems(),onclickInterface2);
        Cursor res = myDB.getAllData();
        while (res.moveToNext()) {
            priceTotal = priceTotal + res.getInt(4)*res.getInt(5);
        }
        button2.setText(dec.format(priceTotal));
        recyclerView.setAdapter(CustomAdapter2);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

    }
    private Cursor getAllItems() {
        return mDatabase.query(
                itemHelper.OrderEntry.Table_Name,
                null,
                null,
                null,
                null,
                null,
                itemHelper.OrderEntry.COLUMN_PRICE+ " DESC"
        );
    }
    public static Context getAppContext() {
        return CheckOut.context;}
    public void removeAt(int position) {
        mExampleList2.remove(position);
        RecyclerView.getAdapter().notifyItemRemoved(position);
        RecyclerView.getAdapter().notifyItemRangeChanged(position, mExampleList2.size());
    }
}
