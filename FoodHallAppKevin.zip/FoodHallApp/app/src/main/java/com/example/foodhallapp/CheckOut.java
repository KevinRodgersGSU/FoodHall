package com.example.foodhallapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.icu.text.DecimalFormat;
import android.icu.text.NumberFormat;
import android.os.Bundle;
import android.os.Parcelable;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class CheckOut extends AppCompatActivity {
    String  c2[],c3[];
    ArrayList<String> c1;
    int cam[];
    ArrayList<Integer> cimages;
    onClickInterface onclickInterface2;
    RecyclerView RecyclerView;
    private MyAdapter myAdapter2;
    private ArrayList<ExampleItem> mExampleList2,mExampleList3;
    private static Context context;
    private Double price = 0.00;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CheckOut.context = getApplicationContext();
        NumberFormat dec= new DecimalFormat("#0.00");
        setContentView(R.layout.activity_check_out);
        RecyclerView = findViewById(R.id.RecyclerView);
        Button button2= findViewById(R.id.price);
        Intent intent = getIntent();
        Bundle b=intent.getExtras();
        c1=b.getStringArrayList("s1");
        String[] c2=b.getStringArray("s2");
        String[] c3=b.getStringArray("s3");
        int[] cam = b.getIntArray("am");
        cimages = b.getIntegerArrayList("images");
        mExampleList2 = new ArrayList<ExampleItem>(MainActivity.mExampleList);
        mExampleList3 = new ArrayList<ExampleItem>();
        for(ExampleItem item : mExampleList2){
            if(item.getam()==0){
                mExampleList3.add(item);
            }
            else{
                price = price + Double.parseDouble(item.gets3())*item.getam();
            }
        }
        button2.setText(dec.format(price));
        mExampleList2.removeAll(mExampleList3);
        onclickInterface2 = new onClickInterface() {
            int z=0;
            @Override
            public void setClick(int abc,String T1,String T2,String T3,int T4) {
                ExampleItem currentItem = mExampleList2.get(abc);
                for(ExampleItem item : MainActivity.mExampleList){
                    if(item.getimg()==currentItem.getimg()){
                        Toast.makeText(CheckOut.this,currentItem.gets1(),Toast.LENGTH_LONG).show();
                        MainActivity.mExampleList.set(z,new ExampleItem(currentItem.gets1(),currentItem.gets2(),currentItem.gets3(),currentItem.getimg(),0));
                        MainActivity.myAdapter.notifyDataSetChanged();
                        mExampleList2.set(abc,new ExampleItem(T1,T2,T3,T4,0));
                        myAdapter2.notifyDataSetChanged();
                        removeAt(abc);
                        price = price - Double.parseDouble(item.gets3())*item.getam();
                        button2.setText(price.toString());
                        break;}
                else{
                z++;}
                }
            }
        };
        if(mExampleList2!=null){
        myAdapter2 = new MyAdapter(mExampleList2,this,onclickInterface2);
        RecyclerView.setAdapter(myAdapter2);}
        RecyclerView.setLayoutManager(new LinearLayoutManager(this));


    }
    public static Context getAppContext() {
        return CheckOut.context;}
    public void removeAt(int position) {
        mExampleList2.remove(position);
        RecyclerView.getAdapter().notifyItemRemoved(position);
        RecyclerView.getAdapter().notifyItemRangeChanged(position, mExampleList2.size());
    }
}
