package com.example.foodhallapp;

public interface onClickInterface {
    void setClick(int abc,String T1,String T2,String T3,int T4);

}

