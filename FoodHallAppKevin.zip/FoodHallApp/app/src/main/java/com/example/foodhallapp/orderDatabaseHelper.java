package com.example.foodhallapp;

import android.content.ContentValues;
import android.content.Context;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.example.foodhallapp.itemHelper.*;
import com.google.gson.JsonObject;

import androidx.annotation.Nullable;
public class orderDatabaseHelper extends SQLiteOpenHelper {
    private final static String DATABASE_NAME = "ordersList.db";
    private final static int DATABASE_VERSION = 1;
    ContentValues contentValues = new ContentValues();
    public orderDatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        //SQLiteDatabase db = this.getWritableDatabase();
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        final String SQL_CREATE_ORDER_TABLE = "CREATE TABLE " +
                OrderEntry.Table_Name + " (" +
                OrderEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                OrderEntry.COLUMN_NAME + " INTEGER, " +
                OrderEntry.COLUMN_DESC + " TEXT, " +
                OrderEntry.COLUMN_PRICE + " TEXT, " +
                OrderEntry.COLUMN_IMG + " INTEGER, " +
                OrderEntry.COLUMN_AM + " INTEGER " +
                ");";
        db.execSQL(SQL_CREATE_ORDER_TABLE);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + OrderEntry.Table_Name);
        onCreate(db);
    }
    public boolean modifyData(int am){
        SQLiteDatabase db = this.getWritableDatabase();
        am++;
        contentValues.put(OrderEntry.COLUMN_AM, am);
        long result = db.insert(OrderEntry.Table_Name, null, contentValues);
        if(result ==-1)
            return false;
        else
            return true;
    }

    public boolean insertData(String Name, String Desc, String Price, int img, int am){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(OrderEntry.COLUMN_NAME, Name);
        contentValues.put(OrderEntry.COLUMN_DESC, Desc);
        contentValues.put(OrderEntry.COLUMN_PRICE, Price);
        contentValues.put(OrderEntry.COLUMN_IMG, img);
        contentValues.put(OrderEntry.COLUMN_AM, am);
        long result = db.insert(OrderEntry.Table_Name, null, contentValues);
        if(result ==-1)
            return false;
        else
            return true;
    }


    public Cursor getAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("SELECT * FROM "+OrderEntry.Table_Name,null);
        return res;
    }
    public int getLastOrder(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("SELECT * FROM "+OrderEntry.Table_Name,null);
        res.moveToLast();
        int lastOrderNum = Integer.valueOf(res.getString(0));
        return lastOrderNum;
    }
    public Cursor getCurrentOrder(){
        SQLiteDatabase db = this.getWritableDatabase();
        int currOrder = getLastOrder()+1;
        Cursor orderInfo = db.rawQuery("SELECT * FROM "+OrderEntry.Table_Name+" WHERE "+OrderEntry._ID+"="+currOrder,null);
        return orderInfo;
    }
}

