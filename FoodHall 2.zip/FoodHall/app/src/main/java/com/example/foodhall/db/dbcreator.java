package com.example.foodhall.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class dbcreator extends SQLiteOpenHelper {
    private static final String LOG = "DatabaseHelper";

    // Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "contactsManager";

    // Table Names
    private static final String TABLE_USER = "user";
    private static final String TABLE_VENDOR= "vendor";
    private static final String TABLE_Orders = "orders";
    private static final String TABLE_RestInfo = "restinfo";

    

}
