package com.example.foodhall.user;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.foodhall.R;
import com.example.foodhall.vendor.LoginVendorActivity;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void gotoLoginUserActivity(View v){
        Intent intent = new Intent(this, LoginUserActivity.class);
        startActivity(intent);
    }
    public void gotoLoginVendorActivity(View v){
        Intent intent = new Intent(this, LoginVendorActivity.class);
        startActivity(intent);
    }
}